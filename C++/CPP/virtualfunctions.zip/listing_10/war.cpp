#include <iostream>
#include <vector>


#include "weapons.h"

using std::vector;
using std::cout;
using std::endl;

int main()
{
    M777_Howitzer mh;
    ICBM icbm;
    
    return 0;
}
