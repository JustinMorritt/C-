#include <iostream>
#include <vector>


#include "weapons.h"

using std::vector;
using std::cout;
using std::endl;

int main()
{
    Tazer t;
    t.fire();
    Weapon w;
    w.fire();
    
    return 0;
}
