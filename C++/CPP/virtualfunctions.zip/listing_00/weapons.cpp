#include <iostream>
#include "weapons.h"

using std::cout;
using std::endl;

void Weapon::fire()
{
    cout << "Weapon::fire() executed."  << endl;
}

