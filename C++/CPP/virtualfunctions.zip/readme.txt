Each directory contains a Makefile for Windows (Makefilewin) and one for CNU C++ (MakefileNix).  

Simply unzip and execute make (or nmake) from the command prompt in each directory.

