#include "weapons.h"


int main()
{
    M777_Howitzer mh;
    mh.fire();
    AK47 ak;
    ak.fire();
    Tazer t;
    t.fire();
    BFG9000 bfg;
    bfg.fire();
    BowieKnife bk;
    bk.fire();
    PointyStick ps;
    ps.fire();
    ICBM icbm;
    icbm.fire();
    return 0;
}
